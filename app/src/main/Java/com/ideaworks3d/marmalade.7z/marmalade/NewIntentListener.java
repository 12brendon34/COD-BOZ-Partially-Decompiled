package com.ideaworks3d.marmalade;

public interface NewIntentListener {
      void onNewIntentEvent(NewIntentEvent var1);
}
