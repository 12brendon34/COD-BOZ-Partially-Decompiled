package com.ideaworks3d.marmalade.event;

public interface RequestPermissionsResultListener {
      void onRequestPermissionsResultEvent(RequestPermissionsResultEvent var1);
}
