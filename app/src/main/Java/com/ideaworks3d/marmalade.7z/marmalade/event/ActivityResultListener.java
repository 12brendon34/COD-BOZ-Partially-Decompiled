package com.ideaworks3d.marmalade.event;

public interface ActivityResultListener {
      void onActivityResultEvent(ActivityResultEvent var1);
}
